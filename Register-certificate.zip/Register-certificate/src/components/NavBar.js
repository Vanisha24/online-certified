import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import CustomerRegistration from "../components/CustomerRegistration";

import FooterComponent from './FooterComponent';




class NavBar extends Component {
  constructor(props) {
    super(props);
   


    return (
      <div>
        <nav className="navbar navbar-expand navbar-warning bg-light">
          <Link to={"/"} className="navbar-brand">
           {/* <img src="https://github.com/yoga2172/CbsFinal/blob/master/coollogo_com-9542159.png?raw=true" width="300" alt="logo"/> */}
          </Link>
          <div className="navbar-nav mr-auto">
            <li className="nav-item">
              <Link to={"/home"} className="nav-link">
                Home
              </Link>
            </li>

            
              <li className="nav-item">
                <Link to={"/register"} className="nav-link">
                  Sign Up
                </Link>
              </li>
            </div>
          )
        </nav>

        <div className="container-fluid">
         
          <Switch>
           
            <Route exact path="/" component={CustomerRegistration} />
            
          </Switch>
          <FooterComponent/>
        </div>
      </div>
    );
  }
}

export default NavBar;