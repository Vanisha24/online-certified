import React,{ Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import CustomerRegistration from './components/CustomerRegistration';
import UpdateRegistration from './components/UpdateRegistration';
import ValidationForm from './components/ValidationForm';
{/*import RegisterService from '../services/RegisterService';*/}
function App() {
  return (
    <div>
      <Router>
        
          <HeaderComponent/>
          <br></br>
          <div className="container">
            <switch>
            
              <Route  exact path = "/" component= {CustomerRegistration}></Route>
              <Route path = "/update/email" component = {UpdateRegistration}></Route>
              <Route  exact path = "/validate" component= {ValidationForm}></Route>

            </switch>
          </div>
          <FooterComponent/> 
       
      </Router>
    </div>
   
    
  );
}

export default App;